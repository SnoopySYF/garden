default_app_config = 'django.contrib.syndication.apps.SyndicationConfig'
